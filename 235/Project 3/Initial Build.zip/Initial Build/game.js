let state = "start";
let maxHP = 20;
let hp = 20;
let shield = 0;
let level = 1;

let firstCard = null;
let lock = false;

const startScreen = document.getElementById("start-screen");
const gameScreen = document.getElementById("game-screen");
const overScreen = document.getElementById("game-over-screen");

const hpText = document.getElementById("hp-text");
const levelText = document.getElementById("level-text");
const shieldText = document.getElementById("shield-text");
const hpFill = document.getElementById("hp-fill");

const grid = document.getElementById("grid");
const buffs = document.getElementById("buffs");

// Buttons
document.getElementById("start-btn").onclick = startGame;
document.getElementById("restart-btn").onclick = () => location.reload();

function startGame() {
    startScreen.classList.add("hidden");
    gameScreen.classList.remove("hidden");
    state = "play";
    setupLevel();
}

function createDeck() {
    let deck = [];

    // special card pairs
    deck.push("hp", "hp");
    deck.push("shield", "shield");

    deck.push("enemy1", "enemy1", "enemy1", "enemy1");
    deck.push("enemy2", "enemy2");

    // remaining inert pairs
    for (let i = 0; i < 3; i++) {
        let n = Math.floor(Math.random() * 90) + 10;
        deck.push("num" + n, "num" + n);
    }

    // random shuffle
    for (let i = deck.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    return deck;
}

function setupLevel() {
    grid.innerHTML = "";
    let deck = createDeck();

    deck.forEach((value, index) => {
        let card = document.createElement("div");
        card.className = "card";
        card.dataset.value = value;
        card.dataset.index = index;
        card.onclick = () => revealCard(card);
        card.textContent = "?";
        grid.appendChild(card);
    });

    updateUI();
}

function revealCard(card) {
    if (lock || card.classList.contains("matched") || card.classList.contains("revealed")) return;

    card.classList.add("revealed");
    card.textContent = card.dataset.value;

    if (!firstCard) {
        firstCard = card;
        return;
    }

    // second card
    lock = true;

    if (card.dataset.value === firstCard.dataset.value) {
        handleMatch(card);
    } else {
        handleMismatch(card);
    }
}

function handleMatch(card) {
    // HP pair
    if (card.dataset.value === "hp") {
        hp = Math.min(maxHP, hp + 3);
        maxHP += 2;
        addBuff("HP+");
    }

    // Shield pair
    if (card.dataset.value === "shield") {
        shield += 1;
        addBuff("SHIELD+");
    }

    card.classList.add("matched");
    firstCard.classList.add("matched");

    setTimeout(() => {
        card.textContent = "";
        firstCard.textContent = "";
        card.style.visibility = "hidden";
        firstCard.style.visibility = "hidden";

        firstCard = null;
        lock = false;

        checkWin();
    }, 300);

    updateUI();
}

function handleMismatch(card) {
    const v1 = firstCard.dataset.value;
    const v2 = card.dataset.value;

    // Enemy damage
    if (v1.startsWith("enemy") || v2.startsWith("enemy")) {
        let dmg;
        if (v1 === "enemy2" || v2 === "enemy2") {
            dmg = 8;
        } else {
            dmg = 4;
        }

        dmg = Math.floor(dmg * (1 + (level - 1) * 0.3));

        dmg = dmg - shield;
        if (dmg < 0) {
            dmg = 0;
        }

        shield = shield - 1;
        if (shield < 0) {
            shield = 0;
        }

        hp = hp - dmg;
        if (hp <= 0) {
            return gameOver();
        }
    }


    // flip back
    setTimeout(() => {
        card.classList.remove("revealed");
        firstCard.classList.remove("revealed");
        card.textContent = "?";
        firstCard.textContent = "?";

        firstCard = null;
        lock = false;

        updateUI();
    }, 600);
}

function updateUI() {
    hpText.textContent = `HP: ${hp} / ${maxHP}`;
    shieldText.textContent = `Shield: ${shield}`;
    levelText.textContent = `Level: ${level}`;

    let hpPercent = Math.max(0, hp / maxHP * 100);
    hpFill.style.width = hpPercent + "%";
}

function addBuff(text) {
    let b = document.createElement("div");
    b.className = "buff";
    b.textContent = text;
    buffs.appendChild(b);
}

function checkWin() {
    const remaining = [...document.querySelectorAll(".card:not(.matched)")];
    if (remaining.length === 0) {
        level++;
        setupLevel();
    }
}

function gameOver() {
    gameScreen.classList.add("hidden");
    overScreen.classList.remove("hidden");
    document.getElementById("final-level-text").textContent =
        `You reached Level ${level}`;
}
